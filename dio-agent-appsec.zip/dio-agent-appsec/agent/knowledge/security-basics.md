# Fundamentos de segurança

Base de conceitos para o agente usar na skill `skills/vulnerability-analysis/SKILL.md`. Linguagem simples primeiro, termo técnico depois.

## Quatro palavras que se confundem

| Termo | O que é | Analogia (casa) |
|-------|---------|-----------------|
| **Ativo** | Algo que tem valor e precisa ser protegido (dados, sistema, servidor) | A casa e o que tem dentro |
| **Vulnerabilidade** | Fraqueza que pode ser explorada | Uma janela sem trava |
| **Ameaça** | Algo ou alguém que pode explorar a fraqueza | Um ladrão |
| **Risco** | A chance de a ameaça explorar a vulnerabilidade, vezes o estrago que isso causa | A chance de roubarem a casa pela janela e o prejuízo se roubarem |

Resumo: **risco = probabilidade × impacto**. Sem vulnerabilidade ou sem ameaça, o risco cai. Sem contexto, não dá para medi-lo.

## A tríade CIA

Toda análise deve dizer qual destas propriedades é afetada:

- **Confidencialidade:** só quem deve ver, vê. Quebra: vazamento de dados, acesso indevido.
- **Integridade:** a informação não é alterada sem autorização. Quebra: dado adulterado, registro apagado.
- **Disponibilidade:** o sistema funciona quando é preciso. Quebra: serviço fora do ar, ataque de negação de serviço.

Exemplo: SQL Injection em um login pode afetar a confidencialidade (ler dados), a integridade (alterar dados) e a autenticação como um todo.

## Impacto, probabilidade e severidade

- **Impacto:** o que se perde se a falha for explorada.
- **Probabilidade:** quão fácil é explorar e quão exposto o ativo está (internet, rede interna, só local; exige login ou não; exploração conhecida ou não).
- **Severidade:** a combinação dos dois. Depende do contexto: a mesma falha pode ser crítica em produção e baixa em uma VM de laboratório isolada.

Escalas usadas pelo agente: impacto Baixo/Médio/Alto; probabilidade Baixa/Média/Alta; severidade Baixa/Média/Alta/Crítica. A escala é simplificada para estudo. Sistemas formais usam métodos como CVSS.

## Referências que o agente pode citar

- **MITRE ATT&CK:** catálogo de técnicas de ataque (ex.: T1190, exploração de aplicação exposta). https://attack.mitre.org
- **CWE:** catálogo de tipos de fraqueza em software (ex.: CWE-89, SQL Injection). https://cwe.mitre.org
- **OWASP Top 10:** as categorias mais críticas de risco em aplicações web (ex.: A03 Injection). https://owasp.org/www-project-top-ten/

Cite um identificador só com certeza. Na dúvida, diga o nome e peça para conferir no site oficial.

## Boas práticas (defesa)

- **Nunca confie na entrada do usuário.** Valide e trate tudo que vem de fora.
- **Consultas parametrizadas** em vez de montar SQL com texto concatenado.
- **Menor privilégio:** cada usuário, serviço e conta de banco com só o acesso necessário.
- **Defesa em camadas:** não depender de uma única proteção.
- **Atualizações em dia:** sistema e dependências.
- **Segredos fora do código:** senhas e chaves em variáveis de ambiente ou cofre, nunca no repositório.
- **Senhas com hash forte e salt** (ex.: bcrypt, argon2), nunca em texto puro.
- **Superfície mínima:** desligar serviços e portas desnecessários.
- **Autenticação forte:** senha longa e segundo fator quando possível.
- **Logs e monitoramento** para perceber tentativas e agir.
- **Falhar de forma segura:** mensagens de erro que não revelam detalhes internos.

## Ética e legalidade

Testar segurança só é aceitável em sistemas **seus** ou com **autorização expressa**. Em estudo, use laboratórios próprios (VMs locais, DVWA, Metasploitable, plataformas de prática feitas para isso). Testar sistema de terceiros sem permissão é crime em muitos países, inclusive no Brasil.
