"""Valida a correção: rode com `python3 examples/test_login.py` (só stdlib)."""
import app
import app_corrigido

ENTRADA_MALICIOSA = "x' OR '1'='1"

def checar(modulo):
    conn = modulo.criar_banco()
    return (
        modulo.login(conn, "admin", "senha-de-teste"),   # credencial correta
        modulo.login(conn, "admin", "errada"),           # credencial errada
        modulo.login(conn, "admin", ENTRADA_MALICIOSA),  # entrada que tenta quebrar o SQL
    )

print("app.py (vulnerável):  ", checar(app))
print("app_corrigido.py:     ", checar(app_corrigido))
assert checar(app)[2] is True, "esperado: versão vulnerável aceita a entrada maliciosa"
assert checar(app_corrigido) == (True, False, False), "versão corrigida deve negar"
print("OK: SQL Injection mitigado na versão corrigida.")
