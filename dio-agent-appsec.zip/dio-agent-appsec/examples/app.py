"""Login de LABORATÓRIO com falha de segurança proposital (SQL Injection).

Use apenas para estudo, na sua máquina. NÃO use em produção.
Peça ao DIO Agent: "Analise o examples/app.py como especialista em AppSec."
"""
import sqlite3


def criar_banco():
    conn = sqlite3.connect(":memory:")
    conn.execute("CREATE TABLE usuarios (usuario TEXT, senha TEXT)")
    conn.execute("INSERT INTO usuarios VALUES ('admin', 'senha-de-teste')")
    conn.commit()
    return conn


def login(conn, usuario, senha):
    # FALHA: o SQL é montado juntando o texto digitado pela pessoa.
    consulta = (
        "SELECT * FROM usuarios WHERE usuario = '" + usuario
        + "' AND senha = '" + senha + "'"
    )
    return conn.execute(consulta).fetchone() is not None


if __name__ == "__main__":
    conn = criar_banco()
    usuario = input("Usuário: ")
    senha = input("Senha: ")
    print("Acesso liberado" if login(conn, usuario, senha) else "Acesso negado")
