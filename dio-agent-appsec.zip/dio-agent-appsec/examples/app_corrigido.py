"""Versão corrigida do login: consulta parametrizada.

Os valores digitados vão como parâmetros e nunca são interpretados como SQL.
(Para estudo: em um sistema real, guarde a senha com hash forte, como bcrypt ou argon2.)
"""
import sqlite3


def criar_banco():
    conn = sqlite3.connect(":memory:")
    conn.execute("CREATE TABLE usuarios (usuario TEXT, senha TEXT)")
    conn.execute("INSERT INTO usuarios VALUES ('admin', 'senha-de-teste')")
    conn.commit()
    return conn


def login(conn, usuario, senha):
    consulta = "SELECT 1 FROM usuarios WHERE usuario = ? AND senha = ?"
    return conn.execute(consulta, (usuario, senha)).fetchone() is not None


if __name__ == "__main__":
    conn = criar_banco()
    usuario = input("Usuário: ")
    senha = input("Senha: ")
    print("Acesso liberado" if login(conn, usuario, senha) else "Acesso negado")
